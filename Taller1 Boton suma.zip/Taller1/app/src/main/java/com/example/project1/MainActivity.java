package com.example.project1;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText[] nums = new EditText[2];
    private TextView resultado;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Referenciar las variables creadas con las paletas
        nums[0] = findViewById(R.id.num1);
        nums[1] = findViewById(R.id.num2);
        resultado = findViewById(R.id.Resultado);
    }

    public void Suma(View view){
        resultado.setText(String.valueOf(Integer.parseInt(nums[0].getText().toString()) +
                Integer.parseInt(nums[1].getText().toString())));
    }
}